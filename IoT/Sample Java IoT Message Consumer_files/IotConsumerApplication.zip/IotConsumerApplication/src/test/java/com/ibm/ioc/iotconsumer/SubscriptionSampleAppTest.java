package com.ibm.ioc.iotconsumer;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.ibm.ioc.iotconsumer.mqtt.IoTMqttClient;

/**
 * Unit test for simple App.
 */
public class SubscriptionSampleAppTest {
	@Test
	public void testSubscriber_noThread() throws Exception {
		IoTMqttClient client = new IoTMqttClient("9kpzic", "a-9kpzic-wm30rkoo7f", "kjO758Pfu9Ixwno)XC");
		String topic = "iot-2/type/CapAlertSender_V4/id/Seat5_RowG_SectionA_MiamiStadium/evt/capAlert_V4/fmt/json";
		client.connect();
		client.subscribe(topic);
     	Thread.sleep(3000);
		client.publish(topic);
		Thread.sleep(15000);
		client.disconnect();
		
		System.out.println("[I100] Success");
	}
	
	@Test
	public void testSubscriber_withThread() throws Exception {
		String org = "9kpzic";
		String apiKey = "a-9kpzic-wm30rkoo7f";
		String apiToken = "kjO758Pfu9Ixwno)XC";
		String topic = "iot-2/type/CapAlertSender_V4/id/+/evt/+/fmt/json";
		
    	CountDownLatch timerSignal = new CountDownLatch(1);
      	ConsumerRunnable consumerRunnable = new ConsumerRunnable(org, apiKey, apiToken, topic);
        Thread consumerThread = new Thread(consumerRunnable, "Consumer Thread Test");
     	consumerThread.start();
     	Thread.sleep(3000);
     	consumerRunnable.getMqttClient().publish("iot-2/type/CapAlertSender_V4/id/Seat5_RowG_SectionA_MiamiStadium/evt/capAlert_V4/fmt/json");
     	timerSignal.await(15, TimeUnit.SECONDS);
     	consumerRunnable.shutdown();
     	consumerThread.interrupt();
     	
		System.out.println("[I200] Success");
	}
	
}
