package com.ibm.ioc.iotconsumer.mqtt;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class IoTSubscriptionListener implements IMqttMessageListener {

	private static final long SCHEDULE_INTERVAL = 3000L;
	private List<String> messages = new ArrayList<String>();
	private String id;
	Timer messageTimer;
	
	IoTSubscriptionListener(String id) {
		this.id = id;
		initTimer();
	}
	
	private void initTimer() {
		messageTimer = new Timer();
		messageTimer.scheduleAtFixedRate(new MessageTimerTask(), 0L, SCHEDULE_INTERVAL);
	}
	
	public void messageArrived(String topic, MqttMessage msg) throws Exception {
		try {
			synchronized(messages) {
				messages.add(new String(msg.getPayload()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private class MessageTimerTask extends TimerTask {
		
		public void run() {
			processMessages();
		}
		
		private void processMessages() {
			for (int i=0; i<messages.size(); i++) {
				// Do something with message
				System.out.println(String.format("[%s] Message received:\n\tpayload=%s", id, messages.get(i)));
				synchronized(messages) {
					messages.remove(i);
				}
			}
		}
	}

}
