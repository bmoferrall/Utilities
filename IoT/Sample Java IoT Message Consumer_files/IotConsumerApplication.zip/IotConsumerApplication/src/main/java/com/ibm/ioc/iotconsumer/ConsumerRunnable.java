package com.ibm.ioc.iotconsumer;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ibm.ioc.iotconsumer.mqtt.IoTMqttClient;

public class ConsumerRunnable implements Runnable {
    private static final Logger logger = Logger.getLogger(ConsumerRunnable.class);
    private volatile boolean closing = false;
    private String topicName;
    IoTMqttClient client;

    public ConsumerRunnable(String o, String u, String p, String t) {
        client = new IoTMqttClient(o, u, p);
        topicName = t;
        logger.setLevel(Level.INFO);
    }
    
    public IoTMqttClient getMqttClient() {
    	return client;
    }
    
	public void run() {
		int i = 0;
        logger.log(Level.INFO, ConsumerRunnable.class.toString() + " is starting.");

        try {
        	client.connect();
        	client.subscribe(topicName);
            while (!closing) {
                try {
                	if (++i == 10) {
                		logger.log(Level.INFO, "Connected. Waiting for messages...");
                		i = 0;
                	}
                	Thread.sleep(1000);
                } catch (Exception e) {
                    logger.log(Level.WARN, "Consumer closing - caught exception: " + e);
                }
            }
            client.disconnect();
        } finally {
            logger.log(Level.INFO, ConsumerRunnable.class.toString() + " has shut down.");
        }
	}

    public void shutdown() {
        closing = true;
        logger.log(Level.INFO, ConsumerRunnable.class.toString() + " is shutting down.");
    }
}
