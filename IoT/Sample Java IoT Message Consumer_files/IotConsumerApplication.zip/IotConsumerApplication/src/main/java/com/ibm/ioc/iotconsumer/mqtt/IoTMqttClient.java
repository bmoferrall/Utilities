package com.ibm.ioc.iotconsumer.mqtt;

import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Random;
import java.util.UUID;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class IoTMqttClient {
    private static final Logger logger = Logger.getLogger(IoTMqttClient.class);
	private String org;
	private String url;
	private String user;
	private String password;
	private String clientId;
	private MqttAsyncClient mqttClient;
	private String URL_FMT = "ssl://%s.messaging.internetofthings.ibmcloud.com:8883";
    private MqttConnectOptions options;
    private boolean cleanSession = true;
    private Random rnd = new Random();
    private MemoryPersistence persistence;
	private HashMap<String, Integer> subscriptions = new HashMap<String, Integer>();
    
    private final Object connectLock = new Object();
    private static final int RETRY_INTERVAL = 3000;
    private static final int ACTION_TIMEOUT = 5000;
    private static final int MAX_CONNECT_ATTEMPTS = 30;
	
	public IoTMqttClient(String o, String u, String p) {
		org = o;
		url = String.format(URL_FMT, org);
		user = u;
		password = p;
		initialiseClient();
		logger.setLevel(Level.INFO);
	}
	
	private void initialiseClient() {
		try {
			logger.log(Level.INFO, "Initialising mqtt client");
			clientId = String.format("a:%s:%s", org, UUID.randomUUID().toString());
			options = getMqttOptions();
			persistence = new MemoryPersistence();
			mqttClient = new MqttAsyncClient(url, clientId, persistence);
			mqttClient.setCallback(new IoTMqttCallback());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private boolean isCleanSession() {
		return this.cleanSession;
	}
	
	public void setCleanSession(boolean clean) {
		this.cleanSession = clean;
	}
	
	public void connect() {
		int numRetries = 1;
		
		if (!isConnected()) {
			synchronized (connectLock) {
				while (!isConnected() && numRetries++ <= MAX_CONNECT_ATTEMPTS) {
					logger.log(Level.DEBUG, String.format("Attempting to connect to mqtt host [%s] - attempt %d", 
													mqttClient.getServerURI(), numRetries));
					try {
						mqttClient.connect(options, null,
								new IMqttActionListener() {
									public void onSuccess(IMqttToken iMqttToken) {
										logger.log(Level.INFO, String.format("Connected to mqtt host [%s]",
																	mqttClient.getServerURI()));
									}
									public void onFailure(IMqttToken iMqttToken, Throwable e) {
									}
								}).waitForCompletion(ACTION_TIMEOUT);
					} catch (MqttException e) {
						logger.log(Level.WARN, String.format("Failed to connect to requested mqtt host [%s] (%s)",
															mqttClient.getServerURI(), e.getMessage()));
						if (!mqttClient.isConnected()) {
							try {
								Thread.sleep(RETRY_INTERVAL);
							} catch (InterruptedException e1) {
								logger.log(Level.DEBUG, String.format("Failed to wait for retry interval (%s)",
															e.getMessage()));
							}
						}
					}
				}
			}
		}
		if (!isConnected()) {
			logger.log(Level.ERROR, String.format("Failed to connect to server: %s", url));
		}
	}
	
	public boolean isConnected() {
		return this.mqttClient.isConnected();
	}
	
	public void subscribe(String topic) {
		this.subscribe(topic, 0);
	}
	
	public void subscribe(String topic, int qos) {
		try {
			logger.log(Level.INFO, "Subscribing to topic: " + topic);
			mqttClient.subscribe(topic, qos, new IoTSubscriptionListener("I200"))
							.waitForCompletion(ACTION_TIMEOUT);
			subscriptions.put(topic, new Integer(qos));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void unsubscribe(String topic) {
		try {
			mqttClient.unsubscribe(topic).waitForCompletion(ACTION_TIMEOUT);
			subscriptions.remove(topic);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void publish(String topic) {
		publish(topic, generateSampleMessage(), 0);
	}
	
	public void publish(String topic, MqttMessage msg, int qos) {
		try {
			logger.log(Level.INFO, "Publishing to topic: " + topic);
			msg.setQos(qos);
			msg.setRetained(true);
			mqttClient.publish(topic, msg);
		} catch (Exception e) {
			logger.log(Level.ERROR, "Error publishing message");
			e.printStackTrace();
		}
	}
	
	private MqttMessage generateSampleMessage() {
		double temp =  80 + rnd.nextDouble() * 20.0;        
        byte[] payload = String.format("T:%04.2f",temp).getBytes();        
        MqttMessage msg = new MqttMessage(payload); 
        return msg;
	}
	
	public void disconnect() {
		try {
			logger.log(Level.INFO, "Disconnecting client");
			mqttClient.disconnect();
		} catch (MqttException e) {
			e.printStackTrace();
		}
	}
	
	private MqttConnectOptions getMqttOptions() {
		MqttConnectOptions options = new MqttConnectOptions();
		options.setAutomaticReconnect(true);
		options.setCleanSession(true);
		options.setUserName(user);
		options.setPassword(password.toCharArray());
	        
		/*java.security.Security.addProvider(new AcceptAllProvider());
		java.util.Properties sslClientProperties = new Properties();
		sslClientProperties.setProperty("com.ibm.ssl.trustManager","TrustAllCertificates");
		sslClientProperties.setProperty("com.ibm.ssl.trustStoreProvider","AcceptAllProvider");
		options.setSSLProperties(sslClientProperties);*/

		options.setSocketFactory(getSSLSocketFactory());
		
		return options;
	}
	
	private SSLSocketFactory getSSLSocketFactory()  {
		SSLContext sslContext = null;
		
		try {
			sslContext = SSLContext.getInstance("TLSv1.2");
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			InputStream certFile = IoTMqttClient.class.getResourceAsStream("/messaging.pem");
			Certificate ca = cf.generateCertificate(certFile);
			 
			KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
			keyStore.load(null, null);
			keyStore.setCertificateEntry("ca", ca);
			TrustManagerFactory tmf = TrustManagerFactory.getInstance("PKIX");
			tmf.init(keyStore);
			//sslContext.init(null, tmf.getTrustManagers(), new java.security.SecureRandom());
			
			// Init with defaults instead. Server will send cert to client when connecting
			sslContext.init(null, null, null);
		}
		catch (Exception e) {
			logger.log(Level.ERROR, e.getMessage(), e);
		}
		return sslContext.getSocketFactory();
	}

	private class IoTMqttCallback implements MqttCallbackExtended {

		public void connectionLost(Throwable cause) {
			logger.log(Level.ERROR, String.format("Connection to Mqtt Client lost: %s", cause.getMessage()));
			logger.log(Level.INFO, "Attempting to reconnect client to server...");
			connect();
		}

		public void messageArrived(String topic, MqttMessage message) throws Exception {
			logger.log(Level.DEBUG, String.format("Message received (client callback):\n\t%s", message.getPayload()));
		}

		public void deliveryComplete(IMqttDeliveryToken token) {
			try {
				logger.log(Level.DEBUG, String.format("Message delivery complete for topic:\n\t%s", 
													String.join(", ", token.getTopics())));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void connectComplete(boolean reconnect, String serverURI) {
			if (reconnect) {
				logger.log(Level.DEBUG, String.format("Successfully reconnected to %s", serverURI));
				if (isCleanSession()) {
				    Iterator<Entry<String, Integer>> iterator = subscriptions.entrySet().iterator();
				    while (iterator.hasNext()) {
				        Entry<String, Integer> subscription = iterator.next();
				        String topic = subscription.getKey();
				        Integer qos = subscription.getValue();
				        logger.log(Level.INFO, String.format("Resubscribing to topic '%s' with qos=%d", topic, qos));
				        try {
				        	mqttClient.subscribe(topic, qos.intValue()).waitForCompletion(ACTION_TIMEOUT);
						} catch (Exception e) {
							logger.log(Level.ERROR, "Error while resubscribing to topic: " + topic);
							e.printStackTrace();
						}
				    }
				}
				
			}
		}
		
	}
	 
}
