package com.ibm.ioc.iotconsumer.cert;

public class AcceptAllX509TrustManager implements
		javax.net.ssl.X509TrustManager {
	public void checkClientTrusted(
			java.security.cert.X509Certificate[] certificateChain,
			String authType) throws java.security.cert.CertificateException {
		report("Client authtype=" + authType);
		for (java.security.cert.X509Certificate certificate : certificateChain) {
			report("Accepting:" + certificate);
		}
	}

	public void checkServerTrusted(
			java.security.cert.X509Certificate[] certificateChain,
			String authType) throws java.security.cert.CertificateException {
		report("Server authtype=" + authType);
		for (java.security.cert.X509Certificate certificate : certificateChain) {
			report("Accepting:" + certificate);
		}
	}

	public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		return new java.security.cert.X509Certificate[0];
	}

	private static void report(String string) {
		System.out.println(string);
	}
}