package com.ibm.ioc.iotconsumer.cert;

public class AcceptAllTrustManagerFactory extends javax.net.ssl.TrustManagerFactorySpi {
	public AcceptAllTrustManagerFactory() {}
	protected void engineInit(java.security.KeyStore keystore) {}
	protected void engineInit(javax.net.ssl.ManagerFactoryParameters parameters) {}
	protected javax.net.ssl.TrustManager[] engineGetTrustManagers() {
		return new javax.net.ssl.TrustManager[] { new AcceptAllX509TrustManager() };
	}
}
