package com.ibm.ioc.iotconsumer.cert;

public class AcceptAllProvider extends java.security.Provider {
	private static final long serialVersionUID = 1L;
	public AcceptAllProvider() {
		super("AcceptAllProvider", 1.0, "Trust all X509 certificates");
		put("TrustManagerFactory.TrustAllCertificates", AcceptAllTrustManagerFactory.class.getName());
	}
}