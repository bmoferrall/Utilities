package com.ibm.ioc.iotconsumer;

import java.util.Properties;

import org.junit.Test;

import com.ibm.iotf.client.app.ApplicationClient;

/**
 * Unit test for simple App.
 */
public class SubscriptionSampleAppTest 
{
	@Test
	public void testSubscriber() throws Exception {
		String org = "9kpzic";
		String apiKey = "a-9kpzic-cfbqvnuh2h";
		String apiToken = "T-LN4Nd8onlBKol8s_";
		
        Properties options = new Properties();
        options.put("org", org);
        options.put("id", "app" + (Math.random() * 10000));
        options.put("Authentication-Method","apikey");
        options.put("API-Key", apiKey);
        options.put("Authentication-Token", apiToken);

        ApplicationClient appClient = new ApplicationClient(options);
        TestEventCallback eventCallback = new TestEventCallback();
        appClient.connect();
        appClient.setEventCallback(eventCallback);
        Thread consumerThread = new Thread(eventCallback, "Event Call Back");
     	consumerThread.start();
        appClient.subscribeToDeviceEvents();
        Thread.sleep(30000);
	}
	
}
