package com.ibm.ioc.iotconsumer;

import com.ibm.iotf.client.app.Command;
import com.ibm.iotf.client.app.Event;
import com.ibm.iotf.client.app.EventCallback;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

public class TestEventCallback implements Runnable, EventCallback {

    private static final Logger logger = Logger.getLogger(TestEventCallback.class);
    private volatile boolean closing = false;
    
    public TestEventCallback() {
    	logger.setLevel(Level.INFO);
    }

    public void processEvent(Event e) {
    	dumpEvent(e);
    }

    public void processCommand(Command cmd) {
        System.out.println("Command received:: " + cmd);
    }

    public void run() {
    	int i = 0;
    	
        while(!closing) {
            try {
            	if (++i == 10) {
            		logger.log(Level.INFO, "Connected. Waiting for messages...");
            		i = 0;
            	}
            	Thread.sleep(1000);
            } catch (Exception e) {
                logger.log(Level.WARN, "Consumer closing - caught exception: " + e);
            }
        }
        logger.log(Level.INFO, TestEventCallback.class.toString() + " is stopping.");
    }
    
    @SuppressWarnings("deprecation")
	private void dumpEvent(Event e) {
    	logger.log(Level.INFO, "Message Received");
        System.out.println(String.format("\tDevice Type=%s\n\tDevice ID=%s\n\tEvent=%s\n\tPayload=%s", 
        		e.getDeviceType(), e.getDeviceId(), e.getEvent(), e.getPayload()));
    }

    public void shutdown() {
        closing = true;
        logger.log(Level.INFO, TestEventCallback.class.toString() + " is shutting down.");
    }
}
