package com.ibm.ioc.iotconsumer;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Arrays;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.ibm.iotf.client.app.ApplicationClient;

public class SubscriptionSampleApp {
	private static final String APP_NAME = "IotConsumerApplicationLibVersion";
    private static final String DEFAULT_DEVICETYPE = "+";
    private static final String DEFAULT_DEVICEID = "+";
    private static final String DEFAULT_EVENT = "+";
    //private static final String DEFAULT_INTERFACE = "+";
    private static final String ARG_DEVICETYPE = "-type";
    private static final String ARG_DEVICEID = "-id";
    private static final String ARG_EVENT = "-evt";
    private static final String ARG_INTERFACE = "-interface";
    private static final Logger logger = Logger.getLogger(SubscriptionSampleApp.class);
    
    private static ApplicationClient appClient = null;
    private static TestEventCallback eventCallback = null;
    private static Thread consumerThread = null;
    
    static {
        Runtime.getRuntime().addShutdownHook(new Thread() {
            @Override
            public void run() {
                logger.log(Level.WARN, "Shutdown received.");
                shutdown();
            }
        });
        Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
            public void uncaughtException(Thread t, Throwable e) {
                logger.log(Level.ERROR, "Uncaught Exception on " + t.getName() + " : " + e, e);
                shutdown();
            }
        });
    }

    private static void printUsage() {
        System.out.println("\n"
                + "Usage:\n"
                + "    java -jar " + APP_NAME + ".jar \n"
                + "              <ORGID> < API-KEY -> key:token > [" + ARG_DEVICETYPE + "]\n"
                + "              [" + ARG_DEVICEID + "] [" + ARG_EVENT + "]\n"
                + "where:\n"
                + "    ORGID\n"
                + "        Required. Organisation ID\n"
                + "    API-KEY\n"
                + "        Required. API key:token pair to access messaging subsystem\n"
                + "    " + ARG_DEVICETYPE + "\n"
                + "        Optional. Device id (default=" + DEFAULT_DEVICETYPE + ")\n"
                + "    " + ARG_DEVICEID + "\n"
                + "        Optional. Device type (default=" + DEFAULT_DEVICEID + ")\n"
                + "    " + ARG_EVENT + "\n"
                + "        Optional. Event (default=" + DEFAULT_EVENT + ")\n"/*
                + "    " + ARG_INTERFACE + "\n"
                + "        Optional. Logical Interface ID (default=" + DEFAULT_INTERFACE + ")\n"*/);
    }
    
    public static void main(String args[])  {
        String apiKey = null;
        String apiToken = null;
        String deviceType = DEFAULT_DEVICETYPE;
        String deviceId = DEFAULT_DEVICEID;
        String event = DEFAULT_EVENT;
        //String logicalInterfaceId = null;
        String org;
        
        logger.setLevel(Level.INFO);
        try {
            if (args.length == 0) {
                printUsage();
                System.exit(-1);
            } else if (args.length < 2) {
                logger.log(Level.ERROR, "Missing required arguments.");
                printUsage();
                System.exit(-1);
            }

            org = args[0];
            if (args[1].contains(":")) {
                String[] credentials = args[1].split(":");
                apiKey = credentials[0];
                apiToken = credentials[1];
            } else {
                logger.log(Level.ERROR, "API-KEY argument must contain colon separating key and token");
                printUsage();
                System.exit(-1);
            }
            
            if (args.length > 2) {
                try {
                    final ArgumentParser argParser = ArgumentParser.builder()
                            .option(ARG_DEVICETYPE)
                            .option(ARG_DEVICEID)
                            .option(ARG_EVENT)
                            .option(ARG_INTERFACE)
                            .build();
                    final Map<String, String> parsedArgs =
                            argParser.parseArguments(Arrays.copyOfRange(args, 2, args.length));
                    if (parsedArgs.containsKey(ARG_DEVICETYPE)) {
                        deviceType = parsedArgs.get(ARG_DEVICETYPE);
                    }
                    if (parsedArgs.containsKey(ARG_DEVICEID)) {
                        deviceId = parsedArgs.get(ARG_DEVICEID);
                    }
                    if (parsedArgs.containsKey(ARG_EVENT)) {
                        event = parsedArgs.get(ARG_EVENT);
                    }
                    /*if (parsedArgs.containsKey(ARG_INTERFACE)) {
                        logicalInterfaceId = parsedArgs.get(ARG_INTERFACE);
                    }*/
                } catch (IllegalArgumentException e) {
                    logger.log(Level.ERROR, e.getMessage());
                    System.exit(-1);
                }
            }

            logger.log(Level.INFO, "Organisation: " + org);
            logger.log(Level.INFO, "User: " + apiKey);
            logger.log(Level.INFO, "Password: " + apiToken);
            
            Properties options = new Properties();
            options.put("org", org);
            options.put("id", "app" + (Math.random() * 10000));
            options.put("Authentication-Method","apikey");
            options.put("API-Key", apiKey);
            options.put("Authentication-Token", apiToken);

            appClient = new ApplicationClient(options);
            eventCallback = new TestEventCallback();
            appClient.connect();
            appClient.setEventCallback(eventCallback);
            consumerThread = new Thread(eventCallback, "Event Call Back");
         	consumerThread.start();
            appClient.subscribeToDeviceEvents(deviceType, deviceId, event);

        } catch (Exception e) {
        	logger.log(Level.ERROR, "Exception occurred, application will terminate", e);
            System.exit(-1);
        }
    }
    

    private static void shutdown() {
    	if (eventCallback != null)
    		eventCallback.shutdown();
    }

}
