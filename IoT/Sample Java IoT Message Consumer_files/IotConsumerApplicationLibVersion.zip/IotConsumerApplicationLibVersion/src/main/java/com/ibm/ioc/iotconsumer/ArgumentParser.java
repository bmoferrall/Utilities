package com.ibm.ioc.iotconsumer;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

public class ArgumentParser {
    static class ArgumentParserBuilder {
        private final Set<String> flags = new HashSet<String>();
        private final Set<String> options = new HashSet<String>();

        private ArgumentParserBuilder() {}

        ArgumentParserBuilder flag(final String name) {
            flags.add(name);
            return this;
        }

        ArgumentParserBuilder option(final String name) {
            options.add(name);
            return this;
        }

        ArgumentParser build() {
            return new ArgumentParser(this);
        }

        private Set<String> flags() {
            return flags;
        }

        private Set<String> options() {
            return options;
        }
    }

    private final Set<String> flags;
    private final Set<String> options;

    private ArgumentParser(final ArgumentParserBuilder builder) {
        this.flags = builder.flags();
        this.options = builder.options();
    }

    static ArgumentParserBuilder builder() {
        return new ArgumentParserBuilder();
    }

    Map<String, String> parseArguments(final String... argArray) throws IllegalArgumentException {
        final Queue<String> args = new LinkedList<String>(Arrays.asList(argArray));
        final Map<String, String> result = new HashMap<String, String>();
        while (!args.isEmpty()) {
            final String arg = args.poll();
            if (flags.contains(arg)) {
                result.put(arg, "");
            } else if (options.contains(arg)) {
                final String value = args.poll();
                if (value == null) {
                    throw new IllegalArgumentException("Command line argument '" + arg
                            + "' must be followed by another argument");
                }
                result.put(arg, value);
            } else {
                throw new IllegalArgumentException("Unexpected command line argument: " + arg);
            }
        }
        return result;
    }
}
