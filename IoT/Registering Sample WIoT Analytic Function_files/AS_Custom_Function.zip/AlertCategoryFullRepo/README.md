# FullAlertCategory
Generate full category name
