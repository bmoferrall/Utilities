PACKAGE_URL = 'git+https://1917daa22b392a9a955cbd6f28bbac41a3a84149@github.com/bmoferrall/FullAlertCategory.git@'

from iotfunctions.preprocessor import BaseTransformer

class FullAlertCategory(BaseTransformer):
    '''
    Generate full category name from abbreviation
    '''    
    url = PACKAGE_URL
    
    def __init__(self, abbrev_category, full_alert_category = 'full_alert_category'):
                
        self.category = abbrev_category
        self.full_alert_category = full_alert_category
        self.input_items = [abbrev_category]
        self.output_item = full_alert_category
        super().__init__()
        self.inputs = ['input_items']
        self.outputs = ['output_item']
    # end def

    def getFullCategory(self,row):
        category_map = {'Geo':'Geophysical',
                        'Met':'Meteoroligical',
                        'Safety': 'General emergency and public safety',
                        'Security': 'Law enforcement, military, homeland and local/private security',
                        'Rescue': 'Rescue and Recovery',
                        'Fire': 'Fire Suppression and Rescue',
                        'Health': 'Medical and Public Health',
                        'Env': 'Pollution and Other Environmental',
                        'Transport': 'Public and Private Transportation',
                        'Infra': 'Utility, telecommunication, other non-transport infrastructure',
                        'CBRNE': 'Chemical, Biological, Radiological, Nuclear or High-yield Explosive threat or attack',
                        'Other': 'Other Events'}

        try:
            full_category = category_map[row[self.category]]
        except Exception as e:
            full_category = 'Undefined'
        # end try

        return full_category
    # end def
        
    def execute(self, df):
        df = df.copy()

        df[self.full_alert_category] = df.apply(self.getFullCategory, axis=1)
        
        return df
   # end def
