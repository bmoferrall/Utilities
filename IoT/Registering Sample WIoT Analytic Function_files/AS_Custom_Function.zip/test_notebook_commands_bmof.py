# In[1]:

get_ipython().system(u'pip install ibm_db --upgrade')
get_ipython().system(u'pip install ibm_db_sa --upgrade')

get_ipython().system(u'pip install git+https://@github.com/ibm-watson-iot/functions.git@ --upgrade')
get_ipython().system(u'pip install --user git+https://1917daa22b392a9a955cbd6f28bbac41a3a84149@github.com/bmoferrall/FullAlertCategory.git@ --upgrade')

# In[2]:

credentials = {
    "connection" : "dashdb",
    "host": "dashdb-entry-yp-dal09-09.services.dal.bluemix.net",
    "password": "3q1Qu_qiFBL_",
    "port": 50000,
    "database": "BLUDB",
    "db": "BLUDB",
    "username": "dash10952",
    "tenant_id":"IOC_Dev",
    "tennant_id":"IOC_Dev",
    "as_api_host": "api-us.connectedproducts.internetofthings.ibmcloud.com",
    "as_api_key" : "a-9kpzic-cfbqvnuh2h",
    "as_api_token" : "********************",
    "objectStorage": {
      "region": "us-south",
      "url": "s3-api.us-geo.objectstorage.softlayer.net",
      "username": "oicZqbghu77srSuPy2qW",
      "password": "********************"
    },
    "config": {
      "objectStorageEndpoint": "https://s3-api.us-geo.objectstorage.softlayer.net",
      "bos_runtime_bucket": "bmof-iociot-buckets"
    }
}

# In[3]:

import pandas as pd
import os

os.environ['DB_CONNECTION_STRING'] = 'DATABASE=%s;HOSTNAME=%s;PORT=%s;PROTOCOL=TCPIP;UID=%s;PWD=%s;' %(credentials["database"],credentials["host"],credentials["port"],credentials["username"],credentials["password"])
os.environ['API_BASEURL'] = 'https://%s' %credentials['as_api_host']
os.environ['API_KEY'] = credentials['as_api_key']
os.environ['API_TOKEN'] = credentials['as_api_token']

# In[4]:

import datetime as dt
import json
from sqlalchemy import Column, Integer, String, Float, DateTime, Boolean, func
from iotfunctions.bif import IoTCosFunction
from iotfunctions.metadata import EntityType, make_sample_entity
from iotfunctions.db import Database
from iotfunctions.preprocessor import BaseTransformer, BaseDatabaseLookup, ComputationsOnStringArray
from iotfunctions.util import cosSave,cosLoad

# In[5]:

db_schema = None
db = Database(credentials=credentials)
entity = make_sample_entity(db=db,  name='ioc_sample_entity', drop_existing=False)

# In[6]:

df = db.read_table(entity.name,schema=db_schema)
#df.head(1).transpose()
df.head(10)

# In[7]:

def column_sum(df,parameters):
    '''
    Columnwise sum of multiple input columns. No custom parameters required.
    '''
    rf = df.copy()
    rf[parameters['output_item']] = df[parameters['input_items']].sum(axis=1)
    return rf

# In[8]:

colsum = IoTCosFunction(function_name = column_sum,
                        input_items = ['temp','grade'] ,
                        output_item = 'column_sum')
df = entity.exec_pipeline(colsum, register=True)
#df.head(1).transpose()
df.head(10)

# In[9]:

from FullAlertCategory.FullAlertCategory import FullAlertCategory

# In[10]:

df = db.read_table('IOT_CAPALERTSENDER_V4',schema=db_schema)
#df.head(1).transpose()
df.head(10)

# In[11]:

rdf = fullAlertCategory.execute(df)
rdf.head(10)

# In[12]:

fullAlertCategory.register(df,credentials=credentials)
